(function () {
  const CFG = {
    TABLE_SELECTORS: ['.ak-editor-content table', '.wiki-content table', 'table'],
    HEADER_SELECTORS: ['.sticky-header table'],
    FLAG: '__ctaw_locked',
    THROTTLE_MS: 300
  };

  const throttle = (fn, ms) => {
    let t, last = 0;
    return (...args) => {
      const now = Date.now();
      if (now - last >= ms) {
        last = now; fn(...args);
      } else {
        clearTimeout(t);
        t = setTimeout(() => { last = Date.now(); fn(...args); }, ms - (now - last));
      }
    };
  };

  function getColumnCount(table) {
    const rows = Array.from(table.rows || []);
    if (!rows.length) return 0;
    return Math.max(...rows.map(r => r.cells.length));
  }

  // Read the actual rendered column widths (not content width), averaging cells in each column
  function readNaturalColumnWidths(table) {
    // Temporarily ensure auto layout to let browser compute widths naturally
    const prevLayout = table.style.tableLayout;
    table.style.tableLayout = 'auto';

    const colCount = getColumnCount(table);
    if (!colCount) { table.style.tableLayout = prevLayout; return []; }

    const sums = new Array(colCount).fill(0);
    const counts = new Array(colCount).fill(0);

    const rows = Array.from(table.rows || []);
    rows.forEach(row => {
      Array.from(row.cells).forEach((cell, idx) => {
        const span = cell.colSpan || 1;
        const w = cell.getBoundingClientRect().width;
        if (span === 1) {
          sums[idx] += w; counts[idx] += 1;
        } else {
          const per = w / span;
          for (let c = 0; c < span && (idx + c) < colCount; c++) {
            sums[idx + c] += per; counts[idx + c] += 1;
          }
        }
      });
    });

    const widths = sums.map((sum, i) => {
      const avg = counts[i] ? (sum / counts[i]) : 0;
      return Math.max(0, Math.round(avg));
    });

    // restore layout (we will set fixed after applying colgroup)
    table.style.tableLayout = prevLayout;
    return widths;
  }

  function applyColgroup(table, widths) {
    if (!widths.length) return;
    let colgroup = table.querySelector('colgroup.__ctaw_colgroup');
    if (!colgroup) {
      colgroup = document.createElement('colgroup');
      colgroup.className = '__ctaw_colgroup';
      table.insertBefore(colgroup, table.firstChild);
    }
    while (colgroup.firstChild) colgroup.removeChild(colgroup.firstChild);

    widths.forEach(w => {
      const col = document.createElement('col');
      // Use exact pixel widths from natural layout and lock them
      col.style.cssText = `width:${w}px !important;`;
      colgroup.appendChild(col);
    });

    table.classList.add(CFG.FLAG);
    table.style.tableLayout = 'fixed';
  }

  function syncStickyHeaders(widths) {
    CFG.HEADER_SELECTORS.forEach(sel => {
      document.querySelectorAll(sel).forEach(ht => {
        const hCols = getColumnCount(ht);
        if (hCols && hCols === widths.length) {
          applyColgroup(ht, widths);
        }
      });
    });
  }

  function lockTable(table) {
    const rows = table.rows || [];
    if (!rows.length || getColumnCount(table) === 0) return;

    const widths = readNaturalColumnWidths(table);
    if (!widths.length) return;

    applyColgroup(table, widths);
    syncStickyHeaders(widths);
  }

  const scan = throttle(() => {
    const selector = CFG.TABLE_SELECTORS.join(',');
    const tables = Array.from(document.querySelectorAll(selector));
    tables.forEach(lockTable);
  }, CFG.THROTTLE_MS);

  document.addEventListener('DOMContentLoaded', scan);
  window.addEventListener('load', scan);
  window.addEventListener('resize', scan, { passive: true });
  window.addEventListener('scroll', scan, { passive: true });

  const mo = new MutationObserver(throttle(() => { scan(); }, CFG.THROTTLE_MS));
  mo.observe(document.documentElement || document.body, { childList: true, subtree: true });
})();

