// Background script - Listen for tab updates
chrome.runtime.onInstalled.addListener(() => {
  console.log('Confluence Table Auto-Width Adjustment plugin installed');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "adjustAllTables") {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {action: "adjustAllTables"});
    });
  }
  return true;
});
