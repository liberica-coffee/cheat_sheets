document.addEventListener('DOMContentLoaded', function() {
  const adjustButton = document.getElementById('adjustButton');
  const resetButton = document.getElementById('resetButton');
  const statusMessage = document.getElementById('statusMessage');
  const statsElement = document.getElementById('stats');
  
  // Update status display
  function updateStatus() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: "getStatus"}, function(response) {
        if (chrome.runtime.lastError) {
          statsElement.textContent = "Please refresh the page and try again";
          adjustButton.disabled = true;
          resetButton.disabled = true;
        } else if (response && response.status === "ready") {
          if (response.isAdjusted) {
            statsElement.textContent = "Table column widths adjusted";
            adjustButton.disabled = true;
            resetButton.disabled = false;
          } else {
            statsElement.textContent = "Tables detected, click to adjust";
            adjustButton.disabled = false;
            resetButton.disabled = true;
          }
        }
      });
    });
  }
  
  // Initial status check
  updateStatus();
  
  // Adjust all tables button click event
  adjustButton.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: "adjustAllTables"}, function(response) {
        if (chrome.runtime.lastError) {
          showStatus("Please refresh the page and try again", "error");
        } else if (response && response.status === "success") {
          showStatus("Table column widths adjusted successfully!", "success");
          setTimeout(updateStatus, 500);
        }
      });
    });
  });
  
  // Reset all tables button click event
  resetButton.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: "resetAllTables"}, function(response) {
        if (chrome.runtime.lastError) {
          showStatus("Please refresh the page and try again", "error");
        } else if (response && response.status === "success") {
          showStatus("Tables reset to original state", "success");
          setTimeout(updateStatus, 500);
        }
      });
    });
  });
  
  // Show status message
  function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = "status " + type;
    
    // Hide message after 3 seconds
    setTimeout(function() {
      statusMessage.className = "status";
      statusMessage.textContent = "";
    }, 3000);
  }
  
  // Update status every 2 seconds
  setInterval(updateStatus, 2000);
});
