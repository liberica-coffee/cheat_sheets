// Main content script - Runs in the page
class TableWidthAdjuster {
  constructor() {
    this.originalWidths = new Map();
    this.isAdjusted = false;
    this.observer = null;
    this.init();
  }

  // Initialize
  init() {
    console.log('Confluence Table Auto-Width Adjustment script loaded');
    
    // Listen for messages from popup or background
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === "adjustAllTables") {
        this.adjustAllTables();
        sendResponse({status: "success"});
      } else if (request.action === "resetAllTables") {
        this.resetAllTables();
        sendResponse({status: "success"});
      } else if (request.action === "getStatus") {
        sendResponse({status: "ready", isAdjusted: this.isAdjusted});
      }
      return true;
    });
    
    // Initial table adjustment
    setTimeout(() => this.adjustAllTables(), 1000);
    
    // Listen for DOM changes
    this.setupMutationObserver();
  }

  // Set up MutationObserver to detect DOM changes
  setupMutationObserver() {
    this.observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === 1) {
              if (node.tagName === 'TABLE' || node.querySelector('table')) {
                setTimeout(() => this.adjustAllTables(), 300);
              }
            }
          });
        }
      });
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // Get all Confluence tables
  getAllTables() {
    const selectors = [
      'table.wikitable',
      'table.confluenceTable',
      'table.table',
      'table:not(.auto-width-adjusted)'
    ];
    
    let tables = [];
    selectors.forEach(selector => {
      const foundTables = document.querySelectorAll(selector);
      foundTables.forEach(table => {
        if (!tables.includes(table) && !table.classList.contains('auto-width-adjusted')) {
          tables.push(table);
        }
      });
    });
    
    return tables;
  }

  // Calculate maximum content width for columns
  calculateColumnWidths(table) {
    const rows = table.rows;
    if (rows.length === 0) return [];
    
    const colCount = this.getColumnCount(rows);
    const maxWidths = new Array(colCount).fill(80); // Minimum width 80px
    
    // Iterate through all rows and columns to calculate maximum width
    for (let i = 0; i < rows.length; i++) {
      const cells = rows[i].cells;
      let colIndex = 0;
      
      for (let j = 0; j < cells.length; j++) {
        const cell = cells[j];
        const colSpan = cell.colSpan || 1;
        const cellContent = cell.textContent.trim();
        
        // Calculate cell content width
        const cellWidth = this.estimateTextWidth(cellContent);
        
        // Distribute width equally across spanned columns
        const widthPerCol = cellWidth / colSpan;
        
        for (let k = 0; k < colSpan; k++) {
          const currentColIndex = colIndex + k;
          if (currentColIndex < maxWidths.length) {
            maxWidths[currentColIndex] = Math.max(maxWidths[currentColIndex], widthPerCol);
          }
        }
        
        colIndex += colSpan;
      }
    }
    
    // Add some padding
    return maxWidths.map(width => Math.min(width + 20, 500));
  }

  // Get table column count
  getColumnCount(rows) {
    let maxCols = 0;
    for (let i = 0; i < rows.length; i++) {
      const cells = rows[i].cells;
      let colCount = 0;
      
      for (let j = 0; j < cells.length; j++) {
        colCount += cells[j].colSpan || 1;
      }
      
      maxCols = Math.max(maxCols, colCount);
    }
    
    return maxCols;
  }

  // Estimate text width
  estimateTextWidth(text) {
    const tempElement = document.createElement('span');
    tempElement.style.visibility = 'hidden';
    tempElement.style.position = 'absolute';
    tempElement.style.whiteSpace = 'nowrap';
    tempElement.style.fontSize = '14px';
    tempElement.style.fontFamily = 'Arial, sans-serif';
    tempElement.textContent = text || ' ';
    
    document.body.appendChild(tempElement);
    const width = tempElement.offsetWidth;
    document.body.removeChild(tempElement);
    
    return width;
  }

  // Get unique table ID
  getTableId(table) {
    if (!table.id) {
      table.id = 'auto-width-table-' + Math.random().toString(36).substr(2, 9);
    }
    return table.id;
  }

  // Adjust single table
  adjustTable(table) {
    if (!table || table.classList.contains('auto-width-adjusted')) {
      return;
    }
    
    // Save original widths
    const tableId = this.getTableId(table);
    if (!this.originalWidths.has(tableId)) {
      const firstRow = table.rows[0];
      const originalWidths = [];
      
      if (firstRow) {
        const cells = firstRow.cells;
        for (let i = 0; i < cells.length; i++) {
          originalWidths.push({
            width: cells[i].style.width || '',
            minWidth: cells[i].style.minWidth || ''
          });
        }
      }
      
      this.originalWidths.set(tableId, {
        table: table,
        widths: originalWidths
      });
    }
    
    // Calculate column widths
    const columnWidths = this.calculateColumnWidths(table);
    
    // Create colgroup element to uniformly set column widths
    let colgroup = table.querySelector('colgroup');
    if (!colgroup) {
      colgroup = document.createElement('colgroup');
      table.insertBefore(colgroup, table.firstChild);
    }
    
    // Clear existing col elements
    while (colgroup.firstChild) {
      colgroup.removeChild(colgroup.firstChild);
    }
    
    // Create col elements based on calculated widths
    for (let i = 0; i < columnWidths.length; i++) {
      const col = document.createElement('col');
      col.style.width = `${columnWidths[i]}px`;
      col.style.minWidth = `${columnWidths[i]}px`;
      colgroup.appendChild(col);
    }
    
    // Set table layout
    table.style.tableLayout = 'fixed';
    table.style.width = 'auto';
    
    // Set width for all cells
    const allCells = table.querySelectorAll('th, td');
    allCells.forEach((cell) => {
      cell.style.boxSizing = 'border-box';
      cell.style.overflow = 'hidden';
      cell.style.textOverflow = 'ellipsis';
      cell.style.whiteSpace = 'nowrap';
    });
    
    // Mark table as adjusted
    table.classList.add('auto-width-adjusted');
    table.setAttribute('data-adjusted', 'true');
  }

  // Adjust all tables
  adjustAllTables() {
    const tables = this.getAllTables();
    console.log(`Found ${tables.length} tables`);
    
    tables.forEach((table, index) => {
      setTimeout(() => {
        try {
          this.adjustTable(table);
        } catch (error) {
          console.error('Error adjusting table:', error);
        }
      }, index * 50);
    });
    
    this.isAdjusted = true;
  }

  // Reset all tables to original width
  resetAllTables() {
    this.originalWidths.forEach((data, tableId) => {
      const table = data.table;
      const widths = data.widths;
      
      table.classList.remove('auto-width-adjusted');
      table.removeAttribute('data-adjusted');
      table.style.tableLayout = '';
      table.style.width = '';
      
      // Remove colgroup
      const colgroup = table.querySelector('colgroup');
      if (colgroup) {
        colgroup.remove();
      }
      
      // Restore cell styles
      const allCells = table.querySelectorAll('th, td');
      allCells.forEach(cell => {
        cell.style.boxSizing = '';
        cell.style.overflow = '';
        cell.style.textOverflow = '';
        cell.style.whiteSpace = '';
        cell.style.width = '';
        cell.style.minWidth = '';
      });
      
      // If saved original widths exist, apply to first row
      const firstRow = table.rows[0];
      if (firstRow && widths.length > 0) {
        const firstRowCells = firstRow.cells;
        for (let i = 0; i < Math.min(firstRowCells.length, widths.length); i++) {
          if (widths[i]) {
            firstRowCells[i].style.width = widths[i].width || '';
            firstRowCells[i].style.minWidth = widths[i].minWidth || '';
          }
        }
      }
    });
    
    this.isAdjusted = false;
  }
}

// Initialize adjuster after page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      if (!window.tableWidthAdjuster) {
        window.tableWidthAdjuster = new TableWidthAdjuster();
      }
    }, 1000);
  });
} else {
  setTimeout(() => {
    if (!window.tableWidthAdjuster) {
      window.tableWidthAdjuster = new TableWidthAdjuster();
    }
  }, 1000);
}
