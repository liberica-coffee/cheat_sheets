// 主内容脚本 - 在页面中运行
class TableWidthAdjuster {
  constructor() {
    this.originalWidths = new Map();
    this.isAdjusted = false;
    this.observer = null;
    this.init();
  }

  // 初始化
  init() {
    console.log('Confluence表格自动列宽调整脚本已加载');
    
    // 监听来自popup或background的消息
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === "adjustAllTables") {
        this.adjustAllTables();
        sendResponse({status: "success"});
      } else if (request.action === "resetAllTables") {
        this.resetAllTables();
        sendResponse({status: "success"});
      } else if (request.action === "getStatus") {
        sendResponse({status: "ready", isAdjusted: this.isAdjusted});
      }
      return true;
    });
    
    // 初始调整表格
    setTimeout(() => this.adjustAllTables(), 1000);
    
    // 监听DOM变化
    this.setupMutationObserver();
  }

  // 设置MutationObserver以检测DOM变化
  setupMutationObserver() {
    this.observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === 1) {
              if (node.tagName === 'TABLE' || node.querySelector('table')) {
                setTimeout(() => this.adjustAllTables(), 300);
              }
            }
          });
        }
      });
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // 获取所有Confluence表格
  getAllTables() {
    const selectors = [
      'table.wikitable',
      'table.confluenceTable',
      'table.table',
      'table:not(.auto-width-adjusted)'
    ];
    
    let tables = [];
    selectors.forEach(selector => {
      const foundTables = document.querySelectorAll(selector);
      foundTables.forEach(table => {
        if (!tables.includes(table) && !table.classList.contains('auto-width-adjusted')) {
          tables.push(table);
        }
      });
    });
    
    return tables;
  }

  // 计算列的最大内容宽度
  calculateColumnWidths(table) {
    const rows = table.rows;
    if (rows.length === 0) return [];
    
    const colCount = this.getColumnCount(rows);
    const maxWidths = new Array(colCount).fill(80); // 最小宽度80px
    
    // 遍历所有行和列，计算最大宽度
    for (let i = 0; i < rows.length; i++) {
      const cells = rows[i].cells;
      let colIndex = 0;
      
      for (let j = 0; j < cells.length; j++) {
        const cell = cells[j];
        const colSpan = cell.colSpan || 1;
        const cellContent = cell.textContent.trim();
        
        // 计算单元格内容宽度
        const cellWidth = this.estimateTextWidth(cellContent);
        
        // 将宽度平均分配到跨列的每一列
        const widthPerCol = cellWidth / colSpan;
        
        for (let k = 0; k < colSpan; k++) {
          const currentColIndex = colIndex + k;
          if (currentColIndex < maxWidths.length) {
            maxWidths[currentColIndex] = Math.max(maxWidths[currentColIndex], widthPerCol);
          }
        }
        
        colIndex += colSpan;
      }
    }
    
    // 添加一些内边距
    return maxWidths.map(width => Math.min(width + 20, 500));
  }

  // 获取表格列数
  getColumnCount(rows) {
    let maxCols = 0;
    for (let i = 0; i < rows.length; i++) {
      const cells = rows[i].cells;
      let colCount = 0;
      
      for (let j = 0; j < cells.length; j++) {
        colCount += cells[j].colSpan || 1;
      }
      
      maxCols = Math.max(maxCols, colCount);
    }
    
    return maxCols;
  }

  // 估算文本宽度
  estimateTextWidth(text) {
    const tempElement = document.createElement('span');
    tempElement.style.visibility = 'hidden';
    tempElement.style.position = 'absolute';
    tempElement.style.whiteSpace = 'nowrap';
    tempElement.style.fontSize = '14px';
    tempElement.style.fontFamily = 'Arial, sans-serif';
    tempElement.textContent = text || ' ';
    
    document.body.appendChild(tempElement);
    const width = tempElement.offsetWidth;
    document.body.removeChild(tempElement);
    
    return width;
  }

  // 获取表格唯一ID
  getTableId(table) {
    if (!table.id) {
      table.id = 'auto-width-table-' + Math.random().toString(36).substr(2, 9);
    }
    return table.id;
  }

  // 调整单个表格
  adjustTable(table) {
    if (!table || table.classList.contains('auto-width-adjusted')) {
      return;
    }
    
    // 保存原始宽度
    const tableId = this.getTableId(table);
    if (!this.originalWidths.has(tableId)) {
      const firstRow = table.rows[0];
      const originalWidths = [];
      
      if (firstRow) {
        const cells = firstRow.cells;
        for (let i = 0; i < cells.length; i++) {
          originalWidths.push({
            width: cells[i].style.width || '',
            minWidth: cells[i].style.minWidth || ''
          });
        }
      }
      
      this.originalWidths.set(tableId, {
        table: table,
        widths: originalWidths
      });
    }
    
    // 计算列宽
    const columnWidths = this.calculateColumnWidths(table);
    
    // 创建colgroup元素来统一设置列宽
    let colgroup = table.querySelector('colgroup');
    if (!colgroup) {
      colgroup = document.createElement('colgroup');
      table.insertBefore(colgroup, table.firstChild);
    }
    
    // 清空现有col元素
    while (colgroup.firstChild) {
      colgroup.removeChild(colgroup.firstChild);
    }
    
    // 根据计算的列宽创建col元素
    for (let i = 0; i < columnWidths.length; i++) {
      const col = document.createElement('col');
      col.style.width = `${columnWidths[i]}px`;
      col.style.minWidth = `${columnWidths[i]}px`;
      colgroup.appendChild(col);
    }
    
    // 设置表格布局
    table.style.tableLayout = 'fixed';
    table.style.width = 'auto'; // 改为auto，不固定宽度
    
    // 设置所有单元格的宽度
    const allCells = table.querySelectorAll('th, td');
    allCells.forEach((cell) => {
      cell.style.boxSizing = 'border-box';
      cell.style.overflow = 'hidden';
      cell.style.textOverflow = 'ellipsis';
      cell.style.whiteSpace = 'nowrap';
    });
    
    // 标记表格已调整
    table.classList.add('auto-width-adjusted');
    table.setAttribute('data-adjusted', 'true');
    
    // 使表头在页面滚动时固定
    this.makeHeaderSticky(table);
  }

  // 使表头在页面滚动时固定
  makeHeaderSticky(table) {
    const thead = table.querySelector('thead');
    if (!thead) return;
    
    // 为表头添加固定样式
    thead.style.position = 'sticky';
    thead.style.top = '0';
    thead.style.zIndex = '100';
    thead.style.backgroundColor = '#f5f5f5';
    
    // 监听窗口滚动，更新表头样式
    const updateHeader = () => {
      const tableRect = table.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      
      // 只有当表格在视口中时才固定表头
      if (tableRect.top < 0 && tableRect.bottom > 0) {
        thead.style.display = 'table-header-group';
      } else {
        thead.style.display = '';
      }
    };
    
    // 初始更新
    updateHeader();
    
    // 监听滚动事件
    window.addEventListener('scroll', updateHeader);
    window.addEventListener('resize', updateHeader);
    
    // 保存事件监听器以便清理
    if (!table._stickyHeaderListeners) {
      table._stickyHeaderListeners = {
        scroll: updateHeader,
        resize: updateHeader
      };
    }
  }

  // 调整所有表格
  adjustAllTables() {
    const tables = this.getAllTables();
    console.log(`找到 ${tables.length} 个表格`);
    
    tables.forEach((table, index) => {
      setTimeout(() => {
        try {
          this.adjustTable(table);
        } catch (error) {
          console.error('调整表格时出错:', error);
        }
      }, index * 50);
    });
    
    this.isAdjusted = true;
  }

  // 清理事件监听器
  cleanupEventListeners(table) {
    if (table._stickyHeaderListeners) {
      window.removeEventListener('scroll', table._stickyHeaderListeners.scroll);
      window.removeEventListener('resize', table._stickyHeaderListeners.resize);
      delete table._stickyHeaderListeners;
    }
  }

  // 重置所有表格到原始宽度
  resetAllTables() {
    this.originalWidths.forEach((data, tableId) => {
      const table = data.table;
      const widths = data.widths;
      
      // 清理事件监听器
      this.cleanupEventListeners(table);
      
      // 移除样式类
      table.classList.remove('auto-width-adjusted');
      table.removeAttribute('data-adjusted');
      
      // 恢复表格布局
      table.style.tableLayout = '';
      table.style.width = '';
      
      // 移除colgroup
      const colgroup = table.querySelector('colgroup');
      if (colgroup) {
        colgroup.remove();
      }
      
      // 恢复表头样式
      const thead = table.querySelector('thead');
      if (thead) {
        thead.style.position = '';
        thead.style.top = '';
        thead.style.zIndex = '';
        thead.style.backgroundColor = '';
        thead.style.display = '';
      }
      
      // 恢复单元格样式
      const allCells = table.querySelectorAll('th, td');
      allCells.forEach(cell => {
        cell.style.boxSizing = '';
        cell.style.overflow = '';
        cell.style.textOverflow = '';
        cell.style.whiteSpace = '';
        cell.style.width = '';
        cell.style.minWidth = '';
      });
      
      // 如果有保存的原始宽度，应用第一行
      const firstRow = table.rows[0];
      if (firstRow && widths.length > 0) {
        const firstRowCells = firstRow.cells;
        for (let i = 0; i < Math.min(firstRowCells.length, widths.length); i++) {
          if (widths[i]) {
            firstRowCells[i].style.width = widths[i].width || '';
            firstRowCells[i].style.minWidth = widths[i].minWidth || '';
          }
        }
      }
    });
    
    this.isAdjusted = false;
  }
}

// 页面加载完成后初始化调整器
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      if (!window.tableWidthAdjuster) {
        window.tableWidthAdjuster = new TableWidthAdjuster();
      }
    }, 1000);
  });
} else {
  setTimeout(() => {
    if (!window.tableWidthAdjuster) {
      window.tableWidthAdjuster = new TableWidthAdjuster();
    }
  }, 1000);
}
