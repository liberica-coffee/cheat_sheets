document.addEventListener('DOMContentLoaded', function() {
  const adjustButton = document.getElementById('adjustButton');
  const resetButton = document.getElementById('resetButton');
  const statusMessage = document.getElementById('statusMessage');
  const statsElement = document.getElementById('stats');
  
  // 更新状态显示
  function updateStatus() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: "getStatus"}, function(response) {
        if (chrome.runtime.lastError) {
          statsElement.textContent = "请刷新页面后使用";
          adjustButton.disabled = true;
          resetButton.disabled = true;
        } else if (response && response.status === "ready") {
          if (response.isAdjusted) {
            statsElement.textContent = "表格列宽已调整";
            adjustButton.disabled = true;
            resetButton.disabled = false;
          } else {
            statsElement.textContent = "检测到表格，点击按钮开始调整";
            adjustButton.disabled = false;
            resetButton.disabled = true;
          }
        }
      });
    });
  }
  
  // 初始状态检查
  updateStatus();
  
  // 调整所有表格按钮点击事件
  adjustButton.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: "adjustAllTables"}, function(response) {
        if (chrome.runtime.lastError) {
          showStatus("请刷新页面后重试", "error");
        } else if (response && response.status === "success") {
          showStatus("表格列宽已调整完成！", "success");
          setTimeout(updateStatus, 500);
        }
      });
    });
  });
  
  // 重置所有表格按钮点击事件
  resetButton.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: "resetAllTables"}, function(response) {
        if (chrome.runtime.lastError) {
          showStatus("请刷新页面后重试", "error");
        } else if (response && response.status === "success") {
          showStatus("表格已重置为原始状态", "success");
          setTimeout(updateStatus, 500);
        }
      });
    });
  });
  
  // 显示状态消息
  function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = "status " + type;
    
    // 3秒后隐藏消息
    setTimeout(function() {
      statusMessage.className = "status";
      statusMessage.textContent = "";
    }, 3000);
  }
  
  // 每2秒更新一次状态
  setInterval(updateStatus, 2000);
});
