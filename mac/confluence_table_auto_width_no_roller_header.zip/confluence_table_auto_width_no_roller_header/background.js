chrome.runtime.onInstalled.addListener(() => {
  console.log('Confluence表格自动列宽调整插件已安装');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "adjustAllTables") {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {action: "adjustAllTables"});
    });
  }
  return true;
});
